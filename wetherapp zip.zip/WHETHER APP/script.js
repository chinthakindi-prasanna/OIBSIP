async function getWeather() {
  const city = document.getElementById("cityInput").value;
  const apiKey = "31c67233bc657f46bb6cfffb6c1fde3a"; // your API key
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  const response = await fetch(url);
  const data = await response.json();

  if (data.cod === "404") {
    document.getElementById("weatherResult").innerHTML = "❌ City not found!";
  } else {
    document.getElementById("weatherResult").innerHTML =
      `🌍 ${data.name}, ${data.sys.country}<br>🌡️ ${data.main.temp}°C<br>☁️ ${data.weather[0].description}`;
  }
}